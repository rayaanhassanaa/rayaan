﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ayaan
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Declaring variables

                string std_name, courses = " ", fullstdinfo, Extra = " ", gender = " ";
                int std_age, std_id;
                // initialing student name from input textbox
                std_name = StdNametextBox1.Text;
                // validating and parsing for id_textbox  using try parse
                if (int.TryParse(StdIDtextBox2.Text, out std_id))
                {
                    /// MessageBox.Show("succes");
                }
                else
                {
                    MessageBox.Show("waxan lambar ahayn lama ogolo");
                }
                // validating and parsing for  age_textbox using int.parse and conditions
                std_age = int.Parse(StdAgetextBox3.Text);
                if (std_age >= 18 & std_age <= 35)
                {
                    //  MessageBox.Show("succes");

                }
                else
                {
                    MessageBox.Show("so geli inta u dhaxayso 18 ilaa 35");
                    return
                    ;
                }


                // male and radio checked
                if (MALEradioButton1.Checked)
                {
                    gender = "male ";
                }
                else if (  FemaleradioButton2.Checked)
                {
                    gender = "female";
                }
                else
                {
                    MessageBox.Show("wa inaad dorata mid ka kid ah jinsiga");
                }

              

                // list box 
                if (courseslist.SelectedIndex != -1)
                {
                    courses = courseslist.SelectedItem.ToString();
                }
                else {
                    MessageBox.Show("so dooro course");
                }
                // Extra_curricular checked 
                if (extra_curricular.Checked)
                {
                    Extra = " yes";


                }
                else
                {
                    Extra = "no";

                }

              





                fullstdinfo = "Name: " + std_name + " \n  ID: " + std_id + "\n  Age: " + std_age + "\n  Gender: " + gender + "\n   Extra_curricular:  " + Extra + "\n   courses:" + courses;
                resultlabel.Text = fullstdinfo;
                

                StdNametextBox1.Focus();
          

        }

        private void button2_Click(object sender, EventArgs e)
        {
             StdNametextBox1.Text = "";
            StdIDtextBox2.Text = "";
            StdAgetextBox3.Text = "";
            MALEradioButton1.Checked = false;
            FemaleradioButton2.Checked = false;
            extra_curricular.Checked = false;
            resultlabel.Text = "";
            courseslist.ClearSelected();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        }
    }

