﻿namespace ayaan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label label3;
            this.stdgroupBox1 = new System.Windows.Forms.GroupBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.StdNametextBox1 = new System.Windows.Forms.TextBox();
            this.StdIDtextBox2 = new System.Windows.Forms.TextBox();
            this.StdAgetextBox3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.MALEradioButton1 = new System.Windows.Forms.RadioButton();
            this.FemaleradioButton2 = new System.Windows.Forms.RadioButton();
            this.resultlabel = new System.Windows.Forms.Label();
            this.courseslist = new System.Windows.Forms.ListBox();
            this.extra_curricular = new System.Windows.Forms.CheckBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            label3 = new System.Windows.Forms.Label();
            this.stdgroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // stdgroupBox1
            // 
            this.stdgroupBox1.Controls.Add(this.FemaleradioButton2);
            this.stdgroupBox1.Controls.Add(label3);
            this.stdgroupBox1.Controls.Add(this.MALEradioButton1);
            this.stdgroupBox1.Controls.Add(this.linkLabel1);
            this.stdgroupBox1.Controls.Add(this.label2);
            this.stdgroupBox1.Controls.Add(this.label1);
            this.stdgroupBox1.Controls.Add(this.StdAgetextBox3);
            this.stdgroupBox1.Controls.Add(this.StdIDtextBox2);
            this.stdgroupBox1.Controls.Add(this.StdNametextBox1);
            this.stdgroupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stdgroupBox1.Location = new System.Drawing.Point(22, 110);
            this.stdgroupBox1.Name = "stdgroupBox1";
            this.stdgroupBox1.Size = new System.Drawing.Size(476, 316);
            this.stdgroupBox1.TabIndex = 0;
            this.stdgroupBox1.TabStop = false;
            this.stdgroupBox1.Text = "groupBoxStudent";
            this.stdgroupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // imageList2
            // 
            this.imageList2.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList2.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // StdNametextBox1
            // 
            this.StdNametextBox1.Location = new System.Drawing.Point(282, 38);
            this.StdNametextBox1.Name = "StdNametextBox1";
            this.StdNametextBox1.Size = new System.Drawing.Size(179, 30);
            this.StdNametextBox1.TabIndex = 0;
            // 
            // StdIDtextBox2
            // 
            this.StdIDtextBox2.Location = new System.Drawing.Point(282, 99);
            this.StdIDtextBox2.Name = "StdIDtextBox2";
            this.StdIDtextBox2.Size = new System.Drawing.Size(179, 30);
            this.StdIDtextBox2.TabIndex = 1;
            // 
            // StdAgetextBox3
            // 
            this.StdAgetextBox3.Location = new System.Drawing.Point(276, 149);
            this.StdAgetextBox3.Name = "StdAgetextBox3";
            this.StdAgetextBox3.Size = new System.Drawing.Size(185, 30);
            this.StdAgetextBox3.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Student Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(71, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Student ID:";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(363, 208);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(0, 25);
            this.linkLabel1.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(72, 159);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(122, 25);
            label3.TabIndex = 1;
            label3.Text = "Studen Age:";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 432);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(114, 40);
            this.button1.TabIndex = 1;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(153, 432);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(92, 39);
            this.button2.TabIndex = 2;
            this.button2.Text = "Clear";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(304, 432);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(100, 37);
            this.button3.TabIndex = 3;
            this.button3.Text = "Exit";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // MALEradioButton1
            // 
            this.MALEradioButton1.AutoSize = true;
            this.MALEradioButton1.Location = new System.Drawing.Point(193, 225);
            this.MALEradioButton1.Name = "MALEradioButton1";
            this.MALEradioButton1.Size = new System.Drawing.Size(80, 29);
            this.MALEradioButton1.TabIndex = 4;
            this.MALEradioButton1.TabStop = true;
            this.MALEradioButton1.Text = "Male";
            this.MALEradioButton1.UseVisualStyleBackColor = true;
            // 
            // FemaleradioButton2
            // 
            this.FemaleradioButton2.AutoSize = true;
            this.FemaleradioButton2.Location = new System.Drawing.Point(317, 230);
            this.FemaleradioButton2.Name = "FemaleradioButton2";
            this.FemaleradioButton2.Size = new System.Drawing.Size(102, 29);
            this.FemaleradioButton2.TabIndex = 5;
            this.FemaleradioButton2.TabStop = true;
            this.FemaleradioButton2.Text = "Female";
            this.FemaleradioButton2.UseVisualStyleBackColor = true;
            // 
            // resultlabel
            // 
            this.resultlabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.resultlabel.Location = new System.Drawing.Point(90, 468);
            this.resultlabel.Name = "resultlabel";
            this.resultlabel.Size = new System.Drawing.Size(393, 171);
            this.resultlabel.TabIndex = 4;
            // 
            // courseslist
            // 
            this.courseslist.FormattingEnabled = true;
            this.courseslist.ItemHeight = 20;
            this.courseslist.Items.AddRange(new object[] {
            "Java",
            "C#",
            "Oracle",
            "Digital"});
            this.courseslist.Location = new System.Drawing.Point(664, 121);
            this.courseslist.Name = "courseslist";
            this.courseslist.Size = new System.Drawing.Size(222, 164);
            this.courseslist.TabIndex = 6;
            this.courseslist.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // extra_curricular
            // 
            this.extra_curricular.AutoSize = true;
            this.extra_curricular.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.extra_curricular.Location = new System.Drawing.Point(696, 366);
            this.extra_curricular.Name = "extra_curricular";
            this.extra_curricular.Size = new System.Drawing.Size(171, 29);
            this.extra_curricular.TabIndex = 7;
            this.extra_curricular.Text = "extra_curricular";
            this.extra_curricular.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ayaan.Properties.Resources.IMG_20231129_WA00001;
            this.pictureBox1.Location = new System.Drawing.Point(22, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(118, 72);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1051, 648);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.extra_curricular);
            this.Controls.Add(this.courseslist);
            this.Controls.Add(this.resultlabel);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.stdgroupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.stdgroupBox1.ResumeLayout(false);
            this.stdgroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox stdgroupBox1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.RadioButton FemaleradioButton2;
        private System.Windows.Forms.RadioButton MALEradioButton1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox StdAgetextBox3;
        private System.Windows.Forms.TextBox StdIDtextBox2;
        private System.Windows.Forms.TextBox StdNametextBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label resultlabel;
        private System.Windows.Forms.ListBox courseslist;
        private System.Windows.Forms.CheckBox extra_curricular;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

